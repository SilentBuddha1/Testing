package com.silent.chautari.utils

object Constants{

    const val USERS : String = "users"

}